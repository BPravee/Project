﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Appointment
{
    public class Program
    {

        public class Department
        {
            Char ch;
            public void AccDepart()
            {
                Console.WriteLine("select Department");
                Console.WriteLine("1. Cardiology");
                Console.WriteLine("2. Radiology");
                ch = char.Parse(Console.ReadLine());
            }


        }

        public class DateTime
        {
            int Date;
            public void AccDateTime()
            {
                Console.WriteLine("Please select date");
                Date = Convert.ToInt32(Console.ReadLine());

                if (Date % 2 == 0)
                {
                    Console.WriteLine("DR. A is available");

                }
                else
                {
                    Console.WriteLine("Dr. B is available");
                }
                Console.ReadLine();

            }
            public class Appointment
            {
                public static void Main(string[]args)
                {
                    Department Dep = new Department();
                    DateTime DT = new DateTime();
                }
            }

        }

    }

}
        

       
            

           
            

            



 
        
    
        
    
