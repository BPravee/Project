﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientInfo
{
    public class Information
    {
        private string Name, LastName, Address, city, Gender;
        private int Age, ContanctNumber;

        public void info()
        {
            Console.WriteLine("\n Enter your name:\t");
            Name = Console.ReadLine();

            Console.WriteLine("\n Enter your Lastname:\t");
            LastName = Console.ReadLine();

            Console.WriteLine("\n Enter your Address:\t");
            Address = Console.ReadLine();

            Console.WriteLine("\n Enter your Gender:\t");
            Gender = Console.ReadLine();

            Console.WriteLine("\n Enter your City:\t");
            city = Console.ReadLine();

            Console.WriteLine("\n Enter your Age:\t");
            Age = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\n Enter your ContactNumber:\t");
            ContanctNumber = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\n Your Details are been registered");
            Console.ReadLine();
        }


    }
    class details
    {
        private static void Main(string[] agrs)
        {
            Information obj = new Information();
            obj.info();
            Console.ReadLine();
        }
    }
}
