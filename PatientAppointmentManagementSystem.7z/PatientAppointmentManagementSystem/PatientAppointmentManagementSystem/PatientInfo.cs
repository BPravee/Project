﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientAppointmentManagementSystem
{
   public class PatientManagement
    {
        static void Main (string [] args)
        {
           PatientInfo.details ObjRef = new PatientInfo.details();
            //ObjRef.
        
        }

            

    }
}
